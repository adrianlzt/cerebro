#undef PACKAGE
#undef VERSION

#define PACKAGE "obdii"
#define VERSION "0.7.0"