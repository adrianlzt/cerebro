--- Streaming CAN data via USB ---
To get started, go through the following steps:

1) Download Wireshark 2.4.7 (32 bit/64 bit) and install it
2) During installation, enable �Wireshark 1" (you don't need WinPcap/USBPcap)
3) Next, power the logger via the CAN bus - and connect it to your PC via USB
4) Open CANvas, go to �LIVE STREAM DATA�, click Connect and then Start

! CANvas will prompt you to auto-install our Wireshark Plugin.

! In rare cases, you may need to manually install USB drivers.

--- Manual Wireshark plugin installation ---
In case you wish to install the plugin manually, extract the *.dll file to your plugins folder
(e.g. 'C:\Program Files\Wireshark\plugins\2.4.7\'). You should use the 32 bit
or 64 bit version, depending on your OS. Note that the zip file also contains 
the plugin source code (you do not need to extract this to use the plugin).

